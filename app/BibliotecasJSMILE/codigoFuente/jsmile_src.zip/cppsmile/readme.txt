Unpack SMILE here to build Win32 binaries.
