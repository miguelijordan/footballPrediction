// jsmile.cpp

#include "jsmile.h"
#include "smilearn.h"
#include "locale.h"

using namespace std;

//-------------------------------------------------------------------------------

void ThrowSmileException(JNIEnv *env, const char *function, int errCode)
{
    string what = "SMILE error ";
    AppendInt(what, errCode);
    what += " in function ";
    what += function;
    
    int errCount = ErrorH.GetNumberOfErrors();
    if (errCount > 0)
    {
        what += ". Logged information: ";
        for (int i = 0; i < errCount; i ++)
        {
            what += ErrorH.GetErrorMessage(i);
            what += "\n";
        }
        
        ErrorH.Flush();
    }

    env->ThrowNew(env->FindClass("smile/SMILEException"), what.c_str()); 
}

//-------------------------------------------------------------------------------


DSL_dataset* GetDataSet(JNIEnv *env, jobject obj) 
{
    return static_cast<DSL_dataset *>(GetNativePtr(env, obj));
}


//-------------------------------------------------------------------------------

DSL_network* GetRelatedNetworkPtr(JNIEnv *env, jobject obj)
{
    jclass cls = env->GetObjectClass(obj);
    jfieldID fid = env->GetFieldID(cls, "net", "Lsmile/Network;");
    return GetNetworkPtr(env, env->GetObjectField(obj, fid));
}

//-------------------------------------------------------------------------------

void SetBkInfo(
    JNIEnv *env, jobject jBkk, jfieldID fid, 
    const char *field1, const char *field2,
    IntPairVector &native)
{
    jobjectArray arr = (jobjectArray)env->GetObjectField(jBkk, fid);
    if (NULL == arr)
    {
        native.clear();
    }
    else
    {
        jfieldID fid1, fid2;
        int count = env->GetArrayLength(arr);
        native.resize(count);

        for (int i = 0; i < count; i ++)
        {
            jobject elem = env->GetObjectArrayElement(arr, i);
            if (NULL == elem)
            {
                string msg = "BkKnowledge array element name can't be null (index ";
                AppendInt(msg, i);
                msg += ')';
                throw invalid_argument(msg);
            }
            
            if (0 == i)
            {
                jclass clsElem = env->GetObjectClass(elem);
                fid1 = env->GetFieldID(clsElem, field1, "I");
	            fid2 = env->GetFieldID(clsElem, field2, "I");
            }

            native[i].first = env->GetIntField(elem, fid1);
            native[i].second = env->GetIntField(elem, fid2);
        }
    }
}

void SetBkKnowledge(JNIEnv *env, jobject jBkk,
    IntPairVector &forcedArcs, IntPairVector &forbiddenArcs, IntPairVector &tiers)
{
    jclass cls = env->GetObjectClass(jBkk);
    jfieldID jForcedID = env->GetFieldID(cls, "forcedArcs", "[Lsmile/learning/BkArcInfo;");
    jfieldID jForbiddenID = env->GetFieldID(cls, "forbiddenArcs", "[Lsmile/learning/BkArcInfo;");
    jfieldID jTiersID = env->GetFieldID(cls, "tiers", "[Lsmile/learning/BkTierInfo;");
    SetBkInfo(env, jBkk, jForcedID, "parent", "child", forcedArcs);
    SetBkInfo(env, jBkk, jForbiddenID, "parent", "child", forbiddenArcs);
    SetBkInfo(env, jBkk, jTiersID, "variable", "tier", tiers);
}

//-------------------------------------------------------------------------------

jobject GetBkInfo(JNIEnv *env, const IntPairVector &native, const char *className)
{
    int count = int(native.size());
    jclass cls = env->FindClass(className);
    jmethodID mid = env->GetMethodID(cls, "<init>", "(II)V");
    jobjectArray arr = env->NewObjectArray(count, cls, NULL);
    for (int i = 0; i < count; i ++)
    {
        jobject elem = env->NewObject(cls, mid, native[i].first, native[i].second);
        env->SetObjectArrayElement(arr, i, elem);
    }

    return arr;
}

jobject GetBkKnowledge(
    JNIEnv *env, 
    const IntPairVector &forced, const IntPairVector &forbidden, const IntPairVector &tiers)
{
    jobject jForced = GetBkInfo(env, forced, "smile/learning/BkArcInfo");
    jobject jForbidden = GetBkInfo(env, forbidden, "smile/learning/BkArcInfo");
    jobject jTiers = GetBkInfo(env, tiers, "smile/learning/BkTierInfo");

    jclass cls = env->FindClass("smile/learning/BkKnowledge");
    jmethodID mid = env->GetMethodID(cls, "<init>", 
        "([Lsmile/learning/BkArcInfo;[Lsmile/learning/BkArcInfo;[Lsmile/learning/BkTierInfo;)V");

    return env->NewObject(cls, mid, jForced, jForbidden, jTiers);
}

//-------------------------------------------------------------------------------

jobject CreateNewNetwork(JNIEnv *env)
{
    jclass cls = env->FindClass("smile/Network");
    jmethodID mid = env->GetMethodID(cls, "<init>", "()V");
    return env->NewObject(cls, mid);
}

//-------------------------------------------------------------------------------

void AppendInt(std::string &s, int i)
{
    char buf[24];
    sprintf(buf, "%d", i);
    s += buf;
}

//-------------------------------------------------------------------------------

DSL_node* ValidateNodeHandle(DSL_network *net, int handle)
{
    DSL_node *node = net->GetNode(handle);
	if (NULL == node)
    {
        string msg = "Invalid node handle: ";
        AppendInt(msg, handle);
        throw invalid_argument(msg);
    }

    return node;
}

int ValidateNodeId(JNIEnv *env, DSL_network *net, jstring nodeId)
{
    NativeString ns(env, nodeId);
    int handle = net->FindNode(ns);
    if (handle < 0)
    {
        string msg = "Invalid node id: ";
        msg += ns;
        throw invalid_argument(msg);
    }
    return handle;
}

DSL_node* ValidateOutcomeIndex(DSL_network *net, int nodeHandle, int outcomeIndex) 
{
	DSL_node *node = ValidateNodeHandle(net, nodeHandle);
    int count = node->Definition()->GetNumberOfOutcomes();
	if (outcomeIndex < 0 || outcomeIndex >= count) 
    {
		string msg;
		msg = "Invalid outcome index ";
		msg += outcomeIndex;
		msg += " for node '";
		msg += node->Info().Header().GetId();
		msg += "', valid indices are 0..";
        AppendInt(msg, count - 1);
		throw invalid_argument(msg);
	}

    return node;
}

int ValidateOutcomeId(JNIEnv *env, DSL_network *net, int nodeHandle, jstring outcomeId) 
{
	DSL_node *node = ValidateNodeHandle(net, nodeHandle);

    NativeString native(env, outcomeId);
    DSL_idArray *outcomeNames = node->Definition()->GetOutcomesNames();
	int outcomeIndex = outcomeNames->FindPosition(native);
	if (outcomeIndex < 0) 
    {
		string msg;
		msg = "Invalid outcome identifier '";
        msg += native;    
		msg += "' for node '";
		msg += node->Info().Header().GetId();
		msg += "'";
		throw invalid_argument(msg);
	}
	
	return outcomeIndex;
}

//-------------------------------------------------------------------------------

jintArray CopyIntArray(JNIEnv *env, const DSL_intArray &native) 
{
	int count = native.NumItems();
	jintArray arr = env->NewIntArray(count);
    const int *p = native.Items();
	for (int i = 0; i < count; i ++)
    {
		env->SetIntArrayRegion(arr, i, 1, (jint *)(p + i));
    }
	return arr;
}

jdoubleArray CopyDoubleArray(JNIEnv *env, DSL_doubleArray &native) 
{
    int count = native.GetSize();
    jdoubleArray arr = env->NewDoubleArray(count);
    const double *p = native.Items();
	for (int i = 0; i < count; i ++)
    {
		env->SetDoubleArrayRegion(arr, i, 1, (jdouble *)(p + i));
    }
	return arr;
}


jobjectArray CopyStringArray(JNIEnv *env, const DSL_stringArray &native)
{
    jclass clazz = env->FindClass("java/lang/String");
	int count = native.NumItems();
	jobjectArray arr = env->NewObjectArray(count, clazz, NULL);
	for (int i = 0; i < count; i ++) 
    {
		env->SetObjectArrayElement(arr, i, env->NewStringUTF(native[i]));
	}
	return arr;
}


jobjectArray HandlesToIds(JNIEnv *env, DSL_network *net, const DSL_intArray &native) 
{
	jclass clazz = env->FindClass("java/lang/String");
    int count = native.NumItems();
	jobjectArray arr = env->NewObjectArray(count, clazz, NULL);
	for (int i = 0; i < count; i ++) 
    {
		const char *id = net->GetNode(native[i])->Info().Header().GetId();
		env->SetObjectArrayElement(arr, i, env->NewStringUTF(id));
	}

	return arr;
}

//-------------------------------------------------------------------------------

DefLocaleCtx::DefLocaleCtx()
{
	defLocale = setlocale(LC_NUMERIC, NULL);
	setlocale(LC_NUMERIC, "C");
}

DefLocaleCtx::~DefLocaleCtx()
{
	setlocale(LC_NUMERIC, defLocale.c_str());
}

//-------------------------------------------------------------------------------
