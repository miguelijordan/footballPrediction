import java.awt.*;
import smile.*;
import smile.learning.*;

// to run this directly from VStudio, type the following in the debugging configuration:
// Command: full path to java.exe (or just java.exe if it's in the PATH)
// Command Arguments: -ea -cp ..\java testApp ..\java\
// Working Directory: $(TargetDir)

class testApp
{
    public static void main(String[] args)
    {
        if (0 == args.length)
        {
            System.out.println("argument needed (path to directory with test files, ending with '/')");
            return;
        }
		
		testDeMorgan();
		testEquations();
				      
        path = args[0];
        
        String networkFile = getFullPath("credit.xdsl");
        String dataFile = getFullPath("credit.txt");
        String voiFile = getFullPath("voitest.xdsl");
        String diagFile = getFullPath("hepar.xdsl");
        String dbnFile = getFullPath("temporal.xdsl");
        
        testDbn(dbnFile);

        DataSet ds = loadDataSet(dataFile);
        testGtt(ds);        
        testNaiveBayes(ds);
        testPc(ds);
        testEm(networkFile, ds);
        testDataSet(dataFile);

        testNetwork(networkFile);
        testParentChildRelations();
        testSubmodels();
        testUserProperty();
        testDocItemInfo();
        
        testVoi(voiFile);
        
        testDiag(diagFile);
        
        testDeleteOutcome();
        
        testProbEvidence(networkFile);
    }

	private static void testDeMorgan()
	{
		System.out.println("*** testing DeMorgan nodes");
		Network net = new Network();
				
		net.addNode(Network.NodeType.DeMorgan, "a");
		net.addNode(Network.NodeType.DeMorgan, "b");
		net.addNode(Network.NodeType.DeMorgan, "c");
		
		net.addArc("c", "a");
		net.addArc("b", "a");
		
		net.setDeMorganPriorBelief("a", 0.11);
		net.setDeMorganPriorBelief("b", 0.22);
		net.setDeMorganPriorBelief("c", 0.33);
		
		net.setDeMorganParentType("a", 0, Network.DeMorganParentType.Cause);
		net.setDeMorganParentType("a", "b", Network.DeMorganParentType.Barrier);
		net.setDeMorganParentWeight(net.getNode("a"), "c", 0.44);
		net.setDeMorganParentWeight("a", 1, 0.55);
		
		net.updateBeliefs();
		
		System.out.println("prior belief for a: " + net.getDeMorganPriorBelief("a"));
		System.out.println("prior belief for b: " + net.getDeMorganPriorBelief("b"));
		System.out.println("prior belief for c: " + net.getDeMorganPriorBelief("c"));
		System.out.println("parent type of a->b: " + net.getDeMorganParentType("a", 0));
		System.out.println("parent type of a->c: " + net.getDeMorganParentType("a", "b"));
		System.out.println("parent weight of a->b: " + net.getDeMorganParentWeight("a", "c"));
		System.out.println("parent weight of a->c: " + net.getDeMorganParentWeight("a", 1));
				
		// DeMorgans only accept incoming arcs from other DeMorgans
		boolean thrown = false;
		try 
		{
			net.addNode(Network.NodeType.Cpt, "d");
			net.addArc("d", "a");
		}
		catch (SMILEException e)
		{
			thrown = true;
		}
		
		assert thrown;
	}

    private static void testEquations()
    {
		System.out.println("*** testing equations");
		
		Network net = new Network();
				
		net.addNode(Network.NodeType.Equation, "a");
		net.addNode(Network.NodeType.Equation, "b");
		net.addNode(Network.NodeType.Equation, "c");
		
		net.setNodeEquation("c", "c = 2 * normal(a, 1) + b");
		net.setNodeEquation("b", "b=5");
		net.setNodeEquationBounds("c", 3, 7);
		double [] bounds = net.getNodeEquationBounds("c");
		assert bounds[0] == 3;
		assert bounds[1] == 7;
		net.updateBeliefs();
		
		double [] value = net.getNodeValue("c");
		System.out.println("Equation: " + net.getNodeEquation("c"));
		System.out.println("Low bound: " + bounds[0]);
		System.out.println("High bound: " + bounds[1]);
		System.out.println("Mean=" + value[0]);
		System.out.println("StdDev=" + value[1]);
		
		for (int idx = 2; idx < value.length; idx ++)
		{
			System.out.print(value[idx]);
			System.out.print(" ");
		}
		System.out.println();
		
		Network net2 = new Network();
		net2.addNode(Network.NodeType.Table, "a");
		net2.addNode(Network.NodeType.Table, "b");
		net2.addNode(Network.NodeType.Table, "c");
		net2.addNode(Network.NodeType.List, "x");
		net2.addNode(Network.NodeType.Mau, "d");
		net2.addArc("x", "d");
		net2.setMauExpressions("d", new String[] { "2 * a + (b - c)/(1 + a)", "a-b/(1+exp(c))" });
		for (String s: net2.getMauExpressions("d")) 
		{
			System.out.println(s);
		}
	}


    private static void testDbn(String fname)
    {
		System.out.println("*** testing DBNs");
		
		Network net = new Network();
	
		net.readFile(fname);


		net.setSliceCount(20);
		System.out.println("slice count: " + net.getSliceCount());
		System.out.println("max temporal order: " + net.getMaxTemporalOrder());

		System.out.println("testing smile.network.unroll...");
		UnrollResults ui = net.unroll();
		System.out.println("node count in unrolled network:" + ui.unrolled.getNodeCount());
		System.out.println("entries in mapping array:" + ui.mapping.length);
		
		for (String id : net.getAllNodeIds())
		{
			if (net.getNodeTemporalType(id) == Network.NodeTemporalType.Plate)
			{
				System.out.println("node " + id + " is on temporal plate");
				System.out.println("its max temporal order: " + net.getMaxNodeTemporalOrder(id));
				System.out.println("all orders:");
				for (int ord : net.getTemporalOrders(id))
				{
					System.out.println(ord);
					for (TemporalInfo ti : net.getTemporalParents(id, ord))
					{
						System.out.println("temporal parent: " + ti.id + ", order: " + ti.order);
					}
					for (TemporalInfo ti : net.getUnrolledParents(id, ord))
					{
						System.out.println("unrolled parent: " + ti.id + ", order: " + ti.order);
					}
				}
				System.out.println();
				
				System.out.println("all unrolled parents");
				for (TemporalInfo ti : net.getUnrolledParents(id))
				{
					System.out.println("unrolled parent: " + ti.id + ", order: " + ti.order);
				}
				
				System.out.println("temporal children");
				for (TemporalInfo ti : net.getTemporalChildren(id))
				{
					System.out.println("temporal child: " + ti.id + ", order: " + ti.order);
				}
			}
			
			assert !net.hasTemporalEvidence(id);
			assert !net.isTemporalEvidence(id, 0);
		}
		
		net.setTemporalEvidence("Product_Reputation", 5, "True");
		net.setTemporalEvidence("Product_Reputation", 7, 1);
		assert net.getTemporalEvidence("Product_Reputation", 5) == 0;
		
		net.updateBeliefs();
		double[] val = net.getNodeValue("Product_Reputation");
		assert val.length == 2 * net.getSliceCount();
		for (double d : val)
		{
			System.out.print(d);
			System.out.print(" ");
		}
		System.out.println();
		
		
		net.clearTemporalEvidence("Product_Reputation", 5);
		assert !net.isTemporalEvidence("Product_Reputation", 5);
		
		net.addTemporalArc("Product_Reputation", "Large_Market_Share", 4);
		assert net.temporalArcExists("Product_Reputation", "Large_Market_Share", 4);
		assert net.getMaxTemporalOrder() == 4;
		assert net.getMaxNodeTemporalOrder("Large_Market_Share") == 4;
		
		double[] def = net.getNodeTemporalDefinition("Large_Market_Share", 4);
		for (double d : def)
		{
			System.out.print(d);
			System.out.print(" ");
		}
		double tmp = def[0];
		def[0] = def[1];
		def[1] = tmp;
		net.setNodeTemporalDefinition("Large_Market_Share", 4, def);
		System.out.println();
				
		net.deleteTemporalArc("Product_Reputation", "Large_Market_Share", 4);
		
		System.out.println("testing noisy node on the plate");
		System.out.println("definition - contains constrained (0/1) columns");
		def = net.getNodeTemporalDefinition("Product_Reputation", 2);
		for (double d : def)
		{
			System.out.print(d);
			System.out.print(" ");
		}
		System.out.println();


		System.out.println("parent strengths");
		int[][] ps = net.getNoisyTemporalParentStrengths("Product_Reputation", 2);
		for (int[] s : ps)
		{
			for (int i : s)
			{
				System.out.print(i);
				System.out.print(" ");
			}
			System.out.println();
		}
		
		ps[2][0] = 1;
		ps[2][1] = 0;
		net.setNoisyTemporalParentStrengths("Product_Reputation", 2, ps);
		System.out.println("changed parent strengths");
		ps = net.getNoisyTemporalParentStrengths("Product_Reputation", 2);
		for (int[] s : ps)
		{
			for (int i : s)
			{
				System.out.print(i);
				System.out.print(" ");
			}
			System.out.println();
		}

		System.out.println("*** DBN test complete, press Enter to continue");
    	System.out.println();
    }

    private static void testProbEvidence(String fname)
    {
        Network net = new Network();
        net.readFile(fname);
        
        net.setEvidence("Worth", "High");
        net.setEvidence("Reliability", "Reliable");
        
        double p = net.probEvidence();
        System.out.println("probEvidence returns " + p);
        
        String[] mapNodes = new String[2];
        mapNodes[0] = "Income";
        mapNodes[1] = "FutureIncome";
        
        System.out.println("Running annealedMap");
        AnnealedMapResults am = net.annealedMap(mapNodes, null);
        
        System.out.println("pm1e = " + am.probM1E);
        System.out.println("pe = " + am.probE);
        System.out.println("state0 = " + net.getOutcomeId(mapNodes[0], am.mapStates[0]));
        System.out.println("state1 = " + net.getOutcomeId(mapNodes[1], am.mapStates[1]));
    }

    private static void testDeleteOutcomeHelper(Network net, int handle)
    {
        System.out.println("outcome count: " + net.getOutcomeCount(handle));
        net.addOutcome(handle, "x1");
        System.out.println("outcome count: " + net.getOutcomeCount(handle));
        net.addOutcome(handle, "x2");
        System.out.println("outcome count: " + net.getOutcomeCount(handle));
        net.deleteOutcome(handle, 0);
        System.out.println("outcome count: " + net.getOutcomeCount(handle));
        net.deleteOutcome(handle, 0);
        System.out.println("outcome count: " + net.getOutcomeCount(handle));
        
        try
        {
            System.out.println("node has 2 outcomes now, trying to remove another outcome");
            net.deleteOutcome(handle, 0);
        }
        catch (SMILEException e)
        {
            System.out.println("exception, as expected");
        }
    }

    
    private static void testDeleteOutcome()
    {
        Network net = new Network();
        int handleCpt = net.addNode(Network.NodeType.Cpt);
        testDeleteOutcomeHelper(net, handleCpt);
        int handleNoisy = net.addNode(Network.NodeType.NoisyMax);
        testDeleteOutcomeHelper(net, handleNoisy);
    }
    
    private static void testDocItemInfo()
    {
        Network net = new Network();
        String nodeId = "id1";
        String outcomeId = "newOutcomeId";
        int handle = net.addNode(Network.NodeType.Cpt, nodeId);
        net.addOutcome(handle, outcomeId);
        int count = 500;
        DocItemInfo[] di = new DocItemInfo[count];
        for (int i = 0; i < count; i ++)
        {
            String suffix = new String();
            suffix = suffix + i;
            di[i] = new DocItemInfo("title" + suffix, "path" + suffix);
            //System.out.println(di[i].title + " " + di[i].path);
        }

        net.setNodeDocumentation(nodeId, di);
        net.setOutcomeDocumentation(nodeId, outcomeId, di);
        
        DocItemInfo[] ret1 = net.getNodeDocumentation(nodeId);
        DocItemInfo[] ret2 = net.getOutcomeDocumentation(nodeId, outcomeId);
        assert ret1.length == di.length;
        assert ret2.length == di.length;
        for (int i = 0; i < count; i ++)
        {
            assert di[i].title.equals(ret1[i].title);
            assert di[i].path.equals(ret1[i].path);
            assert di[i].title.equals(ret2[i].title);
            assert di[i].path.equals(ret2[i].path);
        }
    }
    
    private static void testUserProperty()
    {
        Network net = new Network();
        String nodeId = "id1";
        int handle = net.addNode(Network.NodeType.Cpt, nodeId);
        
        int count = 10;
        UserProperty[] up = new UserProperty[count];
        for (int i = 0; i < count; i ++)
        {
            String suffix = new String();
            suffix = suffix + i;
            up[i] = new UserProperty("prop" + suffix, "val" + suffix);
            //System.out.println(up[i].name + " " + up[i].value);
        }
        
        net.setUserProperties(up);
        net.setNodeUserProperties(nodeId, up);
        
        UserProperty[] ret1 = net.getUserProperties();
        UserProperty[] ret2 = net.getNodeUserProperties(nodeId);
        assert ret1.length == up.length;
        assert ret2.length == up.length;
        for (int i = 0; i < count; i ++)
        {
            assert up[i].name.equals(ret1[i].name);
            assert up[i].value.equals(ret1[i].value);
            assert up[i].name.equals(ret2[i].name);
            assert up[i].value.equals(ret2[i].value);
        }
    }    
    
    private static void testSubmodels()
    {
        Network net = new Network();
        String id1 = "id1";
        String id2 = "id2";
        String sub1 = "sub1";
        String sub2 = "sub2";
        int h1 = net.addNode(Network.NodeType.Cpt, id1);
        int h2 = net.addNode(Network.NodeType.Cpt, id2);
        
        int sMain = net.getMainSubmodel();
        int s1 = net.addSubmodel(sMain, sub1);
        int s2 = net.addSubmodel(net.getMainSubmodelId(), sub2);
        
        net.setSubmodelId(sMain, "mainId");
        net.setSubmodelName(sMain, "mainName");
        net.setSubmodelDescription(sMain, "some description of main submodel");
        
        System.out.println("Main submodel id:   " + net.getSubmodelId(sMain));
        System.out.println("Main submodel name: " + net.getSubmodelName(sMain));
        System.out.println("Main submodel desc: " + net.getSubmodelDescription(sMain));
        
        
        net.setSubmodelOfSubmodel(sub1, sub2);
        net.setSubmodelOfNode(s1, h1);
        net.setSubmodelOfNode(sub2, id2);
        
        System.out.println("sub of node1: " + net.getSubmodelId(net.getSubmodelOfNode(h1)));
        System.out.println("sub of node2: " + net.getSubmodelId(net.getSubmodelOfNode(id2)));
        System.out.println("sub of sub1:  " + net.getSubmodelId(net.getSubmodelOfSubmodel(s1)));
        System.out.println("sub of sub2:  " + net.getSubmodelId(net.getSubmodelOfSubmodel(sub2)));
        
        net.setSubmodelPosition(sub1, 100, 100, 155, 44);
        System.out.println("pos of sub1 changed to " + net.getSubmodelPosition(s1));        
        net.setSubmodelPosition(s1, new Rectangle(200, 200, 44, 155));
        System.out.println("and now it is " + net.getSubmodelPosition(sub1));        
        
        net.deleteSubmodel(sub2);
        net.deleteSubmodel(s1);
        
        System.out.println();
    }
    
    private static void testDiag(String fname)
    {
        System.out.println("Testing smile.DiagNetwork");
        Network net = new Network();
        net.readFile(fname);
        
        DiagNetwork diag = new DiagNetwork(net);
        System.out.println("diag.getPursuedFault: " + diag.getPursuedFault());

        System.out.println("calling update...");
        DiagResults res = diag.update();
        
        System.out.println("observations:");
        for (ObservationInfo oi : res.observations)
        {
            System.out.print(oi.node);
            System.out.print(" ");
            System.out.print(oi.entropy);
            System.out.print(" ");
            System.out.print(oi.cost);
            System.out.print(" ");
            System.out.print(oi.infoGain);
            System.out.println();
        }

        System.out.println("faults:");
        for (FaultInfo fi : res.faults)
        {
            System.out.print(fi.node);
            System.out.print(" ");
            System.out.print(fi.outcome);
            System.out.print(" ");
            System.out.print(fi.probability);
            System.out.print(" ");
            System.out.print(fi.isPursued);
            System.out.println();
        }
        
        System.out.println("faults using DiagNetwork.getFault");
        int count = diag.getFaultCount();
        for (int i = 0; i < count; i ++)
        {
            FaultInfo fi = diag.getFault(i);
            System.out.print(i);
            System.out.print(" ");
            System.out.print(fi.index);
            System.out.print(" ");
            System.out.print(fi.node);
            System.out.print(" ");
            System.out.print(fi.outcome);
            System.out.print(" ");
            System.out.print(fi.probability);
            System.out.print(" ");
            System.out.print(fi.isPursued);
            System.out.println();

        }
        
        System.out.println();
    }
    
    private static void testVoi(String fname)
    {
        System.out.println("Testing smile.ValueOfInfo");
        Network net = new Network();
        net.readFile(fname);
        ValueOfInfo voi = new ValueOfInfo(net);
        voi.addNode("Forecast");
        voi.setDecision("Invest");
        voi.update();
        printDblArray("voi.getValues", voi.getValues());
        printStrArray("voi.getAllNodeIds", voi.getAllNodeIds());
        System.out.println("voi.getPointOfViewId: " + voi.getPointOfViewId());
        System.out.println("voi.getDecisionId: " + voi.getDecisionId());
        System.out.println();
    }

    private static void testNetwork(String fname)
    {
        System.out.println("Testing smile.Network");
        Network net = new Network();
        System.out.println("Reading file: " + fname);
        net.readFile(fname);
        System.out.println("Node count: " + net.getNodeCount());
        
        System.out.println("Color of income node (should be red):   " + net.getNodeBgColor("Income"));
        System.out.println("Color of debit node (should be green):  " + net.getNodeBgColor("Debit"));
        int assets = net.getNode("Assets");
        System.out.println("Color of assets node (should be blue):  " + net.getNodeBgColor(assets));
        System.out.println("Color of assets text (should be white): " + net.getNodeTextColor(assets));
        System.out.println("Color of assets border (should be blk): " + net.getNodeBorderColor(assets));
        System.out.println("Changing assets to red bg, green text and blue border");
        net.setNodeBgColor(assets, Color.RED);
        net.setNodeTextColor(assets, Color.GREEN);
        net.setNodeBorderColor(assets, Color.BLUE);
        System.out.println("New colors: ");
        System.out.println("Color of assets node (should be red):    " + net.getNodeBgColor(assets));
        System.out.println("Color of assets text (should be green):  " + net.getNodeTextColor(assets));
        System.out.println("Color of assets border (should be blue): " + net.getNodeBorderColor(assets));
        
        System.out.println("Border width of income node (should be 1): " + net.getNodeBorderWidth("Income"));
        System.out.println("Border width of assets node (should be 2): " + net.getNodeBorderWidth(assets));
        net.setNodeBorderWidth(assets, 3);
        System.out.println("Border width of assets node (should be 3 now): " + net.getNodeBorderWidth(assets));
        
        net.setNodePosition(assets, 0, 0, 100, 100);
        System.out.println("moved assets to top-left corner, pos is: " + net.getNodePosition(assets));
        net.setNodePosition(assets, new Rectangle(100, 100, 200, 200));
        System.out.println("moved it to 100/100 and increased size, pos is: " + net.getNodePosition(assets));
        
        System.out.println("changing two nodes to noisy " + Network.NodeType.NoisyMax);
        net.setNodeType(assets, Network.NodeType.NoisyMax);
        net.setNodeType("Income", Network.NodeType.NoisyMax);
        System.out.println("now assets is of type: " + net.getNodeType(assets));
        System.out.println("now income is of type: " + net.getNodeType("Income"));
        System.out.println("but debit is unchanged: " + net.getNodeType("Debit"));
        
        System.out.println();
    }

    private static void testParentChildRelations()
    {
        System.out.println("More tests on smile.Network");
        
        Network net = new Network();
        
        System.out.println("New network created, checking header values (id/name/description):");
        System.out.println(net.getId());
        System.out.println(net.getName());
        System.out.println(net.getDescription());
        System.out.println("done.");
        
        String id1 = "id1";
        String id2 = "id2";
        String id3 = "id3";
        
        int h1 = net.addNode(Network.NodeType.Cpt, id1);
        int h2 = net.addNode(Network.NodeType.Cpt, id2);
        int h3 = net.addNode(Network.NodeType.Cpt, id3);
        
        net.addArc(h1, h2);
        net.addArc(id1, id3);

        printIntArray("net.getChildren", net.getChildren(h1));
        printStrArray("net.getChildIds", net.getChildIds(id1));
        printIntArray("net.getParents", net.getParents(h2));
        printStrArray("net.getParentIds", net.getParentIds(id3));
        
        net.addCostArc(h2, h1);
        net.addCostArc(id3, id1);

        printIntArray("net.getCostParents", net.getCostParents(h1));
        printStrArray("net.getCostParentIds", net.getCostParentIds(id1));
        printIntArray("net.getCostChildren", net.getCostChildren(h2));
        printStrArray("net.getCostChildIds", net.getCostChildIds(id3));

        net.setNodeCost(id1, new double[]{1,2,3,4});
        printDblArray("net.getNodeCost", net.getNodeCost(h1));

        
        net.setRanked(h1, true);
        net.setRanked(id2, true);
        net.setMandatory(h1, true);
        net.setMandatory(id2, true);
                
        System.out.println("isRanked: " + net.isRanked(id1));
        System.out.println("isRanked: " + net.isRanked(h2));
        System.out.println("isMandatory: " + net.isMandatory(id1));
        System.out.println("isMandatory: " + net.isMandatory(h2));
        
        net.deleteArc(id1, id2);
        net.deleteArc(h1, h3);
        net.deleteCostArc(id2, id1);
        net.deleteCostArc(h3, h1);
        
        System.out.println();
    }
    
    private static void showNetInfo(Network net)
    {
        System.out.println("Node count: " + net.getNodeCount());
        int count = 0;
        for (int h = net.getFirstNode(); h >= 0; h = net.getNextNode(h))
        {
            if (net.getParents(h).length == 0) count ++;
        }
        System.out.println("Toplevel nodes: " + count);
    }
    
    private static void testNaiveBayes(DataSet ds)
    {
        System.out.println("Testing smile.learning.NaiveBayes");

        NaiveBayes nb = new NaiveBayes();
        String classVar = ds.getVariableId(0);
        nb.setClassVariableId(classVar);
        System.out.println("Class variable id is " + nb.getClassVariableId());
        
        nb.setFeatureSelection(false);
        nb.setPriorsMethod(NaiveBayes.PriorsType.BDeu);
        nb.setNetWeight(1.2345);
        
        System.out.println("featSel=" + nb.getFeatureSelection());
        System.out.println("priMeth=" + nb.getPriorsMethod());
        System.out.println("netWght=" + nb.getNetWeight());
        
        Network net = nb.learn(ds);
        showNetInfo(net);
        System.out.println("Class variable children count: " + net.getChildren(classVar).length);
        
        net.writeFile("tmp-nb.xdsl");
    }
    
    private static void testPc(DataSet ds)
    {
        System.out.println("Testing smile.learning.PC");

        PC pc = new PC();
        
        pc.setSignificance(0.34567);
        pc.setMaxAdjacency(3);
        
        System.out.println("Signif=" + pc.getSignificance());
        System.out.println("maxAdj=" + pc.getMaxAdjacency());

        BkKnowledge bkk = pc.getBkKnowledge();
        assert bkk.forcedArcs.length == 0;
        assert bkk.forbiddenArcs.length == 0;
        assert bkk.tiers.length == 0;
        
        Pattern pat = pc.learn(ds);
        System.out.println("pattern size: " + pat.getSize());
		System.out.println("pattern is DAG? " + pat.isDAG());
		System.out.println("pattern has cycles? " + pat.hasCycle());
	
		int count = pat.getSize();
		for (int i = 0; i < count; i ++)
		{
			for (int j = 0; j < count; j ++)
			{
				switch (pat.getEdge(i, j))
				{
				case Pattern.EdgeType.Directed:
					if (i > j) pat.setEdge(i, j, Pattern.EdgeType.None);
					break;
				case Pattern.EdgeType.Undirected:
					pat.setEdge(i, j, i > j ? Pattern.EdgeType.None : Pattern.EdgeType.Directed);
					break;
				}
			}
		}
	
		Network net = pat.makeNetwork(ds);
		net.writeFile("tmp-pc.xdsl");
    }

    private static void testGtt(DataSet ds)
    {
        System.out.println("Testing smile.learning.GreedyThickThinning");
        GreedyThickThinning gtt = new GreedyThickThinning();
        
        gtt.setNetWeight(2.3456);
        gtt.setPriorsMethod(GreedyThickThinning.PriorsType.BDeu);
        gtt.setMaxParents(5);
        
        System.out.println("maxParn=" + gtt.getMaxParents());
        System.out.println("priMeth=" + gtt.getPriorsMethod());
        System.out.println("netWght=" + gtt.getNetWeight());
        
        BkKnowledge dummy = new BkKnowledge();
        
        BkKnowledge bkk = gtt.getBkKnowledge();
        assert bkk.forcedArcs.length == 0;
        assert bkk.forbiddenArcs.length == 0;
        assert bkk.tiers.length == 0;

        bkk.forcedArcs = new BkArcInfo[3];
        bkk.forbiddenArcs = new BkArcInfo[3];
        bkk.tiers = new BkTierInfo[3];
        bkk.forcedArcs[0] = new BkArcInfo(0, 1);
        bkk.forcedArcs[1] = new BkArcInfo(0, 2);
        bkk.forcedArcs[2] = new BkArcInfo(0, 3);
        bkk.forbiddenArcs [0] = new BkArcInfo(3, 4);
        bkk.forbiddenArcs [1] = new BkArcInfo(3, 5);
        bkk.forbiddenArcs [2] = new BkArcInfo(3, 6);
        bkk.tiers[0] = new BkTierInfo(7, 1);
        bkk.tiers[1] = new BkTierInfo(8, 2);
        bkk.tiers[2] = new BkTierInfo(9, 2);
                
        gtt.setBkKnowledge(bkk);
        bkk = gtt.getBkKnowledge();
        assert bkk.forcedArcs.length == 3;
        assert bkk.forbiddenArcs.length == 3;
        assert bkk.tiers.length == 3;
        
        Network net = gtt.learn(ds);
        showNetInfo(net);
        
        net.writeFile("tmp-gtt.xdsl");
    }

    private static void testEm(String networkFile, DataSet ds)
    {
        System.out.println("Testing smile.learning.EM");
        Network net = new Network();
        net.readFile(networkFile);
        System.out.println("Network loaded from " + networkFile);
        
		System.out.println("calling matchNetwork...");
        DataMatch[] matching = ds.matchNetwork(net);
        for (DataMatch m : matching)
        {
			System.out.println("Matched column " + m.column + " with node " + net.getNodeId(m.node));
        }
        
        String[] fixedNodes = { "RatioDebInc", "Worth" };
        
        System.out.print("Definition of fixed node before EM:");
        for (double d : net.getNodeDefinition("Worth")) System.out.print(" " + d);
        System.out.println();
        
        EM em = new EM();
        em.setEqSampleSize(10);
		em.setRandomizeParameters(false);
        em.setRelevance(false);
        System.out.println("eqSampl=" + em.getEqSampleSize());
        System.out.println("randPar=" + em.getRandomizeParameters());
		System.out.println("relevance=" + em.getRelevance());
        em.learn(ds, net, matching, fixedNodes);
        System.out.println("EM is complete");
        System.out.println();

        System.out.print("Definition of fixed node after EM:");
        for (double d : net.getNodeDefinition("Worth")) System.out.print(" " + d);
        System.out.println();
		System.out.println();
        
        net.writeFile("tmp-em.xdsl");
    }
    
    
    private static DataSet loadDataSet(String fname)
    {
        DataSet ds = new DataSet();
        System.out.println("Reading data file: " + fname);
        ds.readFile(fname);
        return ds;
    }
    
     
    private static void testDataSet(String fname)
    {
        System.out.println("Testing smile.learning.DataSet");
        DataSet ds = loadDataSet(fname);
        System.out.println("Invoking GC");
        System.gc();
        System.out.println("Var count: " + ds.getVariableCount());
        System.gc();
        System.out.println("Rec count: " + ds.getRecordCount());
        
        System.out.println("Creating new dataset, adding int and float variable");
        DataSet ds2 = new DataSet();
        ds2.addIntVariable("x1");
        ds2.addFloatVariable("x2");


        String[] stateNames = new String[10];
        for (int i = 0; i < 10; i ++)
        {
            stateNames[i] = new String("State" + i);
        }
        System.out.println("Setting state names for int variable");
        ds2.setStateNames(0, stateNames);        

        System.out.println("Reading state names back");
        printStrArray("ds2.getStateNames", ds2.getStateNames(0));
        
        System.out.println("Adding records");
        final int REC_COUNT = 1000;
        for (int i = 0; i < REC_COUNT; i ++)
        {
            ds2.addEmptyRecord();
            ds2.setInt(0, i, 10 * i + 5);
            ds2.setFloat(1, i, 1234.567f * i);
        }
        
        System.out.println("Var count: " + ds2.getVariableCount());
        System.out.println("Rec count: " + ds2.getRecordCount());
        
        System.out.println("Reading data back");
        int isum = 0;
        float fsum = 0;
        for (int i = 0; i < ds2.getRecordCount(); i ++)
        {
            isum += ds2.getInt(0, i);
            fsum += ds2.getFloat(1, i);
        }
        
        int expectedIsum = 5 * REC_COUNT + 10 * REC_COUNT * (REC_COUNT - 1) / 2;
        float expectedFsum = 1234.567f * REC_COUNT * (REC_COUNT - 1) / 2;
        
        assert expectedIsum == isum;
        assert expectedFsum == fsum;
        System.out.println("isum=" + isum + ", expected: " + expectedIsum);
        System.out.println("fsum=" + fsum + ", expected: " + expectedFsum);
        
        System.out.println();
    }
    
    private static String path;
    
    private static String getFullPath(String coreName)
    {
        return path + coreName;
    }
    
    private static void printIntArray(String caption, int[] a)
    {
        System.out.print(caption + ": ");
        for (int x : a) 
        {
            System.out.print(x);
            System.out.print(" ");
        }
        System.out.println();
    }

    private static void printStrArray(String caption, String[] a)
    {
        System.out.print(caption + ": ");
        for (String x : a) 
        {
            System.out.print(x);
            System.out.print(" ");
        }
        System.out.println();
    }

    private static void printDblArray(String caption, double[] a)
    {
        System.out.print(caption + ": ");
        for (double x : a) 
        {
            System.out.print(x);
            System.out.print(" ");
        }
        System.out.println();
    }
}
