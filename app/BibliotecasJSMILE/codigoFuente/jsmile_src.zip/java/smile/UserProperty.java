package smile;

public class UserProperty 
{
	public UserProperty(String name, String value) 
	{
		this.name = name;
		this.value = value;
	}

	public String name;
	public String value;
}
