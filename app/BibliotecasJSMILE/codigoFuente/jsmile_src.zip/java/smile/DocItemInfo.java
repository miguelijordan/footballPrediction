package smile;

public class DocItemInfo 
{
	public DocItemInfo(String title, String path) 
	{
		this.title = title;
		this.path = path;
	}

	public String title;
	public String path;
}
