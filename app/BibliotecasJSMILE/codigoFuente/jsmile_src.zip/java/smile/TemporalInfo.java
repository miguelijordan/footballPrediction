package smile;

public class TemporalInfo 
{
	public TemporalInfo(int handle, String id, int order) 
	{
		this.handle = handle;
		this.id = id;
		this.order = order;
	}

	public int handle;
	public String id;
	public int order;
}
