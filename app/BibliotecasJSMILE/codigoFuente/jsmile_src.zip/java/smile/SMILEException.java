package smile;

public class SMILEException extends RuntimeException 
{
	public SMILEException(String msg) 
	{
		super(msg);
	}
}

