package smile.learning;

public class DataMatch
{
	public DataMatch() {}
	
	public DataMatch(int column, int node, int slice) 
	{
		this.column = column;
		this.node = node;
		this.slice = slice;
	}

    public int column;
	public int node;
	public int slice;
}
