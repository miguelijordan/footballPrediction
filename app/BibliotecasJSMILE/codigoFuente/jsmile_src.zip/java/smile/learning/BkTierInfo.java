package smile.learning;

public class BkTierInfo 
{
	public BkTierInfo() {}
	
	public BkTierInfo(int variable, int tier) 
	{
		this.variable = variable;
		this.tier = tier;
	}

	public int variable;
	public int tier;
}
